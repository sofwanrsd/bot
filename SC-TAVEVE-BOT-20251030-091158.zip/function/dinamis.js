require("../setting.js");
const QRCode = require("qrcode");

function toCRC16(str) {
  function charCodeAt(str, i) {
    return str.charCodeAt(i);
  }

  let crc = 0xffff;
  for (let c = 0; c < str.length; c++) {
    crc ^= charCodeAt(str, c) << 8;
    for (let i = 0; i < 8; i++) {
      if (crc & 0x8000) {
        crc = (crc << 1) ^ 0x1021;
      } else {
        crc <<= 1;
      }
      crc &= 0xffff;
    }
  }
  let hex = crc.toString(16).toUpperCase();
  if (hex.length === 3) hex = "0" + hex;
  return hex;
}

async function qrisDinamis(nominal, path) {
  let qris = codeqr;

  // 🔒 Pastikan nominal selalu angka bulat (tanpa titik/koma)
  nominal = String(Math.floor(Number(nominal)));

  // Hapus CRC lama (4 digit terakhir)
  let qris2 = qris.slice(0, -4);

  // Ubah ke dinamis
  let replaceQris = qris2.replace("010211", "010212");

  // Pisahkan di bagian tag negara (5802ID)
  let pecahQris = replaceQris.split("5802ID");

  // Buat tag nominal (54 + length + value)
  const len = String(nominal.length).padStart(2, "0");
  const uang = "54" + len + nominal + "5802ID";

  // Gabung kembali dengan CRC baru
  const payload = pecahQris[0] + uang + pecahQris[1];
  const crc = toCRC16(payload);
  const output = payload + crc;

  // Simpan QR ke file
  await QRCode.toFile(path, output, { margin: 2, scale: 10 });

  return path;
}

module.exports = { qrisDinamis };
