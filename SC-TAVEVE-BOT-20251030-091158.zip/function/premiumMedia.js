// ==========================================
// Premium Media API Wrapper
// ==========================================
const axios = require("axios");
const qs = require("querystring");

/**
 * Mendapatkan riwayat mutasi Premium Media
 * @param {string} username - username dari database.json
 * @param {string} token - authToken dari database.json
 * @param {string} id - id dari database.json (id Orkut / akun terdaftar)
 * @returns {Promise<object>} data JSON dari API Premium Media
 */
async function mutasiPremium(username, token, id) {
  try {
    if (!username || !token || !id) {
      throw new Error("Parameter username, token, dan id wajib diisi.");
    }

    const url = "https://premium-media.id/apiv3/mutasi";
    const body = qs.stringify({ username, token, id });
    const headers = { "Content-Type": "application/x-www-form-urlencoded" };

    const res = await axios.post(url, body, { headers });

    if (!res.data)
      throw new Error("Tidak ada respon dari server Premium Media.");
    return res.data;
  } catch (err) {
    console.error("❌ [mutasiPremium] Error:", err.message);
    return { status: "error", message: err.message };
  }
}

module.exports = { mutasiPremium };
