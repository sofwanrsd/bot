//Orderkuota
global.codeqr =
  "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214416427019363710303UMI51440014ID.CO.QRIS.WWW0215ID20254030285950303UMI5204541153033605802ID5922TAVEVE STORE OK24403656004PALU61059410562070703A016304F384"; //QR string Order Kuota lu

//Database mongodb || Jika ingin menggunakan database lokal tidak perlu diisi
global.mongoURL = "";

//Other
global.botName = "TaveveBOT"; //Nama bot
global.owner = ["6769643060", "5678748710"]; // ← ganti dengan ID Telegram kamu
global.ownerNomer = "5678748710"; //Nomor lu
global.ownerName = "Sofwan Rosidi"; //Nama lu
global.packname = "TAVEVE"; //Seterah
global.author = "Created By Taveve"; //Seterah
global.linkTelegramGroup = "https://chat.whatsapp.com/Kdv063Rocas2FbnPCwmjK5"; //Link gc lu

//Image
global.thumbnail = "./options/image/thumbnail.jpg";

//Message
global.mess = {
  sukses: "Done🤗",
  admin: "Command ini hanya bisa digunakan oleh Admin Grup",
  botAdmin: "Bot Harus menjadi admin",
  owner: "Command ini hanya dapat digunakan oleh owner bot",
  prem: "Command ini khusus member premium",
  group: "Command ini hanya bisa digunakan di grup",
  private: "Command ini hanya bisa digunakan di Private Chat",
  wait: "⏳ Mohon tunggu sebentar...",
  error: {
    lv: "Link yang kamu berikan tidak valid",
    api: "Maaf terjadi kesalahan",
  },
};

//Function buat menu
const fs = require("fs");
const chalk = require("chalk");
const moment = require("moment-timezone");
const path = require("path");

const runtime = (seconds) => {
  const d = Math.floor(seconds / (3600 * 24));
  const h = Math.floor((seconds % (3600 * 24)) / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return `${d}d ${h}h ${m}m ${s}s`;
};

const d = new Date(new Date() + 3600000);
const dateIslam = Intl.DateTimeFormat("id" + "-TN-u-ca-islamic", {
  day: "numeric",
  month: "long",
  year: "numeric",
}).format(d);

//Tampilan menu
global.menu = (prefix, sender, pushname) => {
  return `*🤖 BOT INFO 🤖*
• Bot Name: ${botName}
• Runtime: ${runtime(process.uptime())}
• Owner: @${ownerNomer}

*📖 LIST MENU 📖*
☛ ${prefix}allmenu
☛ ${prefix}infobot
☛ ${prefix}ordermenu`;
};

global.allmenu = (prefix, sender, pushname) => {
  return `*🤖 BOT INFO 🤖*
• Bot Name: ${botName}
• Runtime: ${runtime(process.uptime())}
• Owner: @${ownerNomer}

╭─────╼「 *INFO BOT* 」
│☛ ${prefix}owner
│☛ ${prefix}ping
│☛ ${prefix}runtime
│☛ ${prefix}script
╰─────╼

╭─────╼「 *ORDER MENU* 」
│☛ ${prefix}stok
│☛ ${prefix}buy
╰─────╼

╭─────╼「 *OWNER MENU* 」
│☛ ${prefix}addproduk
│☛ ${prefix}delproduk
│☛ ${prefix}setkode
│☛ ${prefix}setharga
│☛ ${prefix}setjudul
│☛ ${prefix}setdesk
│☛ ${prefix}setsnk
│☛ ${prefix}setprofit
│☛ ${prefix}addstok
│☛ ${prefix}getstok
│☛ ${prefix}delstok
│☛ ${prefix}backup
╰─────╼

╭─────╼「 *STORE MENU* 」
│☛ ${prefix}list
╰─────╼`;
};

global.infobot = (prefix, sender, pushname) => {
  return `*🤖 BOT INFO 🤖*
• Bot Name: ${botName}
• Runtime: ${runtime(process.uptime())}
• Owner: @${ownerNomer}

╭─────╼「 *INFO BOT* 」
│☛ ${prefix}owner
│☛ ${prefix}ping
│☛ ${prefix}runtime
│☛ ${prefix}script
╰─────╼`;
};

global.ownermenu = (prefix, sender, pushname) => {
  return `*🤖 BOT INFO 🤖*
• Bot Name: ${botName}
• Runtime: ${runtime(process.uptime())}
• Owner: @${ownerNomer}

╭─────╼「 *OWNER MENU* 」
│☛ ${prefix}addproduk
│☛ ${prefix}delproduk
│☛ ${prefix}setkode
│☛ ${prefix}setharga
│☛ ${prefix}setjudul
│☛ ${prefix}setdesk
│☛ ${prefix}setsnk
│☛ ${prefix}setprofit
│☛ ${prefix}addstok
│☛ ${prefix}getstok
│☛ ${prefix}delstok
│☛ ${prefix}backup
╰─────╼`;
};

global.storemenu = (prefix, sender, pushname) => {
  return `*🤖 BOT INFO 🤖*
• Bot Name: ${botName}
• Runtime: ${runtime(process.uptime())}
• Owner: @${ownerNomer}

╭─────╼「 *STORE MENU* 」
│☛ ${prefix}list
╰─────╼`;
};

global.ordermenu = (prefix, sender, pushname) => {
  return `*🤖 BOT INFO 🤖*
• Bot Name: ${botName}
• Runtime: ${runtime(process.uptime())}
• Owner: @${ownerNomer}

╭─────╼「 *ORDER MENU* 」
│☛ ${prefix}stok
│☛ ${prefix}stokbycode
│☛ ${prefix}buy
╰─────╼`;
};

let time = moment(new Date()).format("HH:mm:ss DD/MM/YYYY");
let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(
    chalk.greenBright(`[ ${botName} ]  `) +
      time +
      chalk.cyanBright(` "${file}" Telah diupdate!`)
  );
  delete require.cache[file];
  require(file);
});
